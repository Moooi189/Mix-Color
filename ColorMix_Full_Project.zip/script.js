
let colors = [];
let colorDB = [];

fetch('extended_color_names_db.json')
  .then(res => res.json())
  .then(data => colorDB = data)
  .catch(err => console.error("فشل تحميل قاعدة بيانات الألوان:", err));

function addColorPicker() {
  if (colors.length >= 10) return alert("الحد الأقصى 10 ألوان");
  const pickers = document.getElementById('colorPickers');
  const input = document.createElement('input');
  input.type = 'color';
  input.value = '#000000';
  input.onchange = mixColors;
  pickers.appendChild(input);
  colors.push(input);
}

function mixColors() {
  let r = 0, g = 0, b = 0;
  const validColors = colors.filter(c => c.value);
  if (validColors.length === 0) return;

  validColors.forEach(picker => {
    const hex = picker.value;
    const rgb = hexToRgb(hex);
    r += rgb.r;
    g += rgb.g;
    b += rgb.b;
  });

  r = Math.round(r / validColors.length);
  g = Math.round(g / validColors.length);
  b = Math.round(b / validColors.length);
  const mixedHex = rgbToHex(r, g, b);

  document.getElementById('mixedColorBox').style.background = mixedHex;
  document.getElementById('hexCode').textContent = `Hex: ${mixedHex}`;
  document.getElementById('rgbCode').textContent = `RGB: (${r}, ${g}, ${b})`;
  document.getElementById('colorName').textContent = `الاسم التقريبي: ${getColorName(r, g, b)}`;
}

function hexToRgb(hex) {
  const bigint = parseInt(hex.substring(1), 16);
  return {
    r: (bigint >> 16) & 255,
    g: (bigint >> 8) & 255,
    b: bigint & 255
  };
}

function rgbToHex(r, g, b) {
  return "#" + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
}

function getColorName(r, g, b) {
  if (colorDB.length === 0) return "جاري التحميل...";
  let closest = null;
  let minDistance = Infinity;
  colorDB.forEach(color => {
    const distance = Math.sqrt(
      Math.pow(r - color.r, 2) +
      Math.pow(g - color.g, 2) +
      Math.pow(b - color.b, 2)
    );
    if (distance < minDistance) {
      minDistance = distance;
      closest = color;
    }
  });
  return closest ? closest.name : "غير معروف";
}

function loadImage(event) {
  const canvas = document.getElementById('imageCanvas');
  const ctx = canvas.getContext('2d');
  const reader = new FileReader();
  reader.onload = function () {
    const img = new Image();
    img.onload = function () {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      canvas.onclick = function (e) {
        const x = e.offsetX;
        const y = e.offsetY;
        const pixel = ctx.getImageData(x, y, 1, 1).data;
        const hex = rgbToHex(pixel[0], pixel[1], pixel[2]);
        const name = getColorName(pixel[0], pixel[1], pixel[2]);
        document.getElementById('pickedFromImage').textContent =
          `اللون المختار من الصورة: ${hex} (${name})`;
      };
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(event.target.files[0]);
}
